var express= require("express");
var request= require("request");
var faker = require('faker');
var app= express();
var bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({ extended: false }))
var mongoose = require("mongoose");
mongoose.connect("mongodb://localhost/posts");
var postSchema = new mongoose.Schema({
    email:String,
    post: String,
    image:String,
    name: String,
    title: String,
    date: {type: Date, default: Date.now}
});
var Post= mongoose.model("Post", postSchema);

// Post.create(
//     {
//         email: "hi@gmail.com",
//         post: "CP is Cp",
//         name:"yadav"
//     },function(err,post){
//         if(!err){
//             console.log(post);
//         }
//     })
app.set("view engine","ejs");

app.get("/", function(req,res){
    res.render("index");
})

app.get("/about", function(req,res){
    res.render("about");
})

app.get("/contact", function(req,res){
    res.render("contact");
})
app.get("/read", function(req,res){
    Post.find({},function(err, allPosts){
        if(!err){
              res.render("read",{
              posts: allPosts
            });
        }
    })
  
})
app.get("/write", function(req,res){
    res.render("write");
})

app.post("/read", function(req,res){
    var name= req.body.name;
    var post=req.body.post.replace(new RegExp('\r?\n','g'), '<br />');
    var email=req.body.email;
    var title=req.body.title;
    var newC={
        email: email,
        post: post,
        date: Date.now.toDateString,
        name: name,
        title: title
        
    };
    Post.create(newC,function(err,post){
        if(!err){
            console.log(post);
        }
        else{
            console.log(err)
        }
    });
    res.redirect("/read");
    
})

app.get("/read/:id", function(req,res){
    Post.findById(req.params.id,function(err, thePost){
        if(!err){
              res.render("show",{
              posts: thePost
            });
        }
    })
})
app.listen(process.env.PORT,process.env.IP);